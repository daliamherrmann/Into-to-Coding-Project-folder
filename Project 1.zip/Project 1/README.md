


My website is a travel page to document where I went to while I was abroad. 

It includes, headers, footers, articles, css, pictures, videos, ordered list, unordered lists, 3 pages, a table and a flex box. 

I used the main page to show off things I liked the most and a cool video.

I used the second page to show off Egypt and have a picture. 

I used the third page for lessions that I learned. 